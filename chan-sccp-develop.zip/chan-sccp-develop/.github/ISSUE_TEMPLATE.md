[Short description of problem here]

**Reproduction Steps:**

1. [First Step]
2. [Second Step]
3. [Other Steps...]

**chan-sccp version:** (include revision and/or branch if relevant)

**asterisk version:** (include revision and/or branch if relevant)

**Expected behavior:**

[Describe expected behavior here]

**Observed behavior:**

[Describe observed behavior here]

**Screenshots**

(Screenshots which show reproduction steps and/or demonstrate the problem)
[url]

**Addition / Optional Information:**
- Problem started happening recently, didn't happen in an older version of Chan-SCCP: [Yes/No]
- Problem can be reliably reproduced, doesn't happen randomly: [Yes/No]
- Platform:
  - [CPU]
  - [32/64 Bit]
  - [Big/Small Endian]
  - [Operating System]
  - [Operating System Version]
- Direct Contact information: [You can contact me here]
- Log Files (attach .txt / [pastbin](http://pastebin.com/) / [gist](http://gist.github.com/)): [url]
- Comments: [Other Information]

**BTW: Consider making a donation via paypal:**
- https://www.paypal.com/cgi-bin/webscr?&cmd=_donations&business=chan.sccp.b.pp%40gmail.com
